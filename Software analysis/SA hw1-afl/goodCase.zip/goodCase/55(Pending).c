//Program to find f(x) by Lagrange's interpolation method.
#include<stdio.h>
int main()
{
	int
}
