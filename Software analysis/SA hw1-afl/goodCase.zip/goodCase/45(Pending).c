// Program to print sum of factorial series 1/1! + 2/2! +...1/N!
#include<stdio.h>
int main()
{
	int n;
}
