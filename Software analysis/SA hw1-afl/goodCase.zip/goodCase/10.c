//Program to check whether the number is even or add
#include<stdio.h>
int main()
{
	int n;
	printf("Enter the number\t");
	scanf("%d",&n);
	if(n%2==0)
	{
		printf("The Number is Even\t");	
	}
	else
		printf("The Number is Odd\t");
}
