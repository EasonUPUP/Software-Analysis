//Program to accept value of radius and print area of a circle
#include<stdio.h>
int main()
{
	int r;
	printf("Enter the radius of the circle\t");
	scanf("%d",&r);
	printf("The Area of a circle\t%f",(3.14*r*r));
}
