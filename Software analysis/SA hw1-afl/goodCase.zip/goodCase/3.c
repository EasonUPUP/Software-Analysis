//Program to accept values of two numbers and print their addition
#include<stdio.h>
int main()
{
	int a,b;
	printf("Enter Two values\n");
	scanf("%d\n%d",&a,&b);
	printf("The sum is \t%d",a+b);
}
