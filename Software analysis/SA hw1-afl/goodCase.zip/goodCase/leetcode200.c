#include<stdio.h>

void visitIsland(char **gird, int row, int col, int rowSize, int colSize)
{
    if (row < 0 || row >= rowSize || col < 0 || col >= colSize)
        return ;
    else if (gird[row][col] == '1')
    {
        gird[row][col] = '0';
        //上
        visitIsland(gird, row - 1, col, rowSize, colSize);
        //下
        visitIsland(gird, row + 1, col, rowSize, colSize);
        //左
        visitIsland(gird, row, col - 1, rowSize, colSize);
        //右
        visitIsland(gird, row, col + 1, rowSize, colSize);
    }
}
int numIslands(char** grid, int gridSize, int* gridColSize){
    int i, j, c = 0;
    
    if (!grid || gridSize == 0 || *gridColSize == 0)
        return c;
    for (i = 0; i < gridSize; i++)
    {
        for (j = 0; j < *gridColSize; j++)
            if (grid[i][j] == '1')
            {
                visitIsland(grid, i, j, gridSize, *gridColSize);
                c++;
            }
    }
    
    return c;
}
