//Program to assign values of two numbers and print their addition
#include<stdio.h>
int main()
{
	int a=5,b=10;
	printf("%d",a+b);
}

