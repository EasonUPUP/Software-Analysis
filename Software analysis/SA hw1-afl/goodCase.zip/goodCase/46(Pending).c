//Program to calculate the sum of 'n' terms in Taylor series.(77)
