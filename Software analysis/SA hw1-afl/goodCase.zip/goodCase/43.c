// Program to find the square root of a number
#include<stdio.h>
int main()
{
	int n;
	printf("Enter the Number\t");
	scanf("%d",&n);
	printf("The Squar root of %d is %.2f",n,sqrt(n));
}
