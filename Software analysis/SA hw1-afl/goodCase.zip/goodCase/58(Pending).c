//Program for Newton Raphson General
#include<stdio.h>

