//Program to print "Hello World"
#include<stdio.h>
int main()
{
	printf("Hello World");
}
